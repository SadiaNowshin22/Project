
package chat;

/**
 *
 * @author Chayti
 */
public class Chat {   
    public static void main(String[] args) {
    }
    
}
